# Obsidian 三端配置参考包（Git Vault 1.1.1）

本包仅含配置模板和图谱颜色参数，不含插件代码、令牌、个人笔记或日志。

## 文件

- `git-vault/data.json`：适用于首次接入 GitHub API 的手机和平板。
- `colorGroups.json`：Obsidian 全局关系图谱的颜色组参数。

## 手机、平板配置

1. 安装并启用官方 Obsidian Git Vault 1.1.1；此版本要求 Obsidian 1.11.4 或更新。
2. 完全关闭 Obsidian。
3. 在实际 Vault 的 `.obsidian/plugins/git-vault/` 中，将旧 `data.json` 重命名为 `data.json.bak`，保留回退副本。
4. 用文本编辑器修改本包的 `git-vault/data.json`：将 `YOUR_GITHUB_USERNAME` 换为仓库所属账号；按需修改 `Z_Atlas` 和 `main`。
5. 把修改后的 `data.json` 复制到上述插件目录。不要把整个 git-vault 文件夹拿来替换已有插件文件。
6. 重新打开 Obsidian，在插件设置的 Personal access token 中填写当前设备的令牌，检查仓库和分支。
7. 退出再进入设置，核对 Excluded paths 和自动同步开关。模板的智能触发与定时同步均关闭，冲突策略为 manual。
8. 首次同步前检查手机本地有没有独有笔记。对已有远端使用 Sync；不要点 Create & upload。遇到冲突逐个判断，只有本地无独有修改时才选 Keep Remote。

令牌应只授权目标仓库，Contents 为 Read and write，Metadata 为 Read-only。令牌有效不等于已获得目标私有仓库的权限。不要把令牌写进本包或笔记。

模板排除整个 00-Inbox、历史日志附件目录、名称包含“日志”的路径及 .obsidian；这些内容不会通过 GitHub 同步。规则范围请按自己的目录检查，技术笔记的文件名如果包含“日志”也可能被排除。.gitignore 和 .gitkeep 也排除 API 同步，以免它们参与移动端的缺失文件判断。

已有复杂同步配置或既往同步状态时，优先在界面逐项设置；不要未经核对就用模板覆盖。

## 图谱颜色

`colorGroups.json` 只有颜色组，不是完整的 `graph.json`。可对照里面的 query 和 rgb 参数手动设置；rgb 为十进制 RGB 整数。

如果选择编辑配置文件：完全关闭 Obsidian，备份实际 Vault 中的 `.obsidian/graph.json`，只把其中的 `colorGroups` 字段替换为本包的同名字段，保留其他图谱设置。不要直接用 `colorGroups.json` 覆盖整个 `graph.json`。

颜色参考：00 灰蓝 #94A3B8；01 蓝 #60A5FA；02 琥珀 #FBBF24；03 青绿 #2DD4BF；04 淡紫 #C4B5FD；05 粉 #F472B6。日志末端 #B0BCCB；ROS 2 第一轮 #93C5FD。更具体的规则排在宽泛的规则之前。

## 来源

- 官方插件：https://github.com/redoracle/obsidian-git-vault
- 固定版本：https://github.com/redoracle/obsidian-git-vault/releases/tag/1.1.1

模板只记录此次配置选择，不代表已经完整验证离线冲突、自动同步和灾难恢复。请先用无隐私的测试笔记完成双向往返。
